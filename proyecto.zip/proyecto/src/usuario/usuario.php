<?php
class Usuario
{
  public $id; // int
  public $nombre; // string
  public $ap_pat; // string
  public $ap_mat; // string
  public $correo_principal; // string
  public $correo_secundario; // string
  public $tipo_usuario; // string
  public $numero_identificador; // string
  public $password; // string
  public $id_grupo; // int
  public $grupo; // Objeto Grupo
}
