<?php

class Tema
{
  public $id; // int
  public $nombre; // string
  public $descripcion; // string
  public $id_bloque; // int
  public $bloque; // Objeto Bloque
}
