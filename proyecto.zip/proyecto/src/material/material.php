<?php

class Material
{
  public $id; // int
  public $tipo; // string
  public $nombre; // string
  public $descripcion; // string
  public $url; // string
  public $id_subtema; // int
  public $subtema; // Objeto SubTema
}
