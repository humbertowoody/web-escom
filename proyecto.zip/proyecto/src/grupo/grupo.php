<?php

class Grupo
{
  public $id; // int
  public $nombre; // string
}
