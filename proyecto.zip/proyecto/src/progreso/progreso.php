<?php

class Progreso
{
  public $id_usuario; // int
  public $usuario; // Objeto Usuario
  public $id_material; // int
  public $material; // Objeto Material
  public $fecha; // string
}
