<?php

class Duda
{
  public $id; // int
  public $nombre; // string
  public $correo_electronico; // string
  public $asunto; // string
  public $descripcion; // string
  public $resuelta; // boolean
}
