<?php

class Bloque
{
  public $id; // int
  public $nombre; // string
  public $descripcion; // string
  public $id_grupo; // int
  public $grupo; // Objeto Grupo
}
