<?php

class SubTema
{
  public $id; // int
  public $nombre; // string
  public $descripcion; // string
  public $id_tema; // int
  public $tema; // Objeto Tema
}
